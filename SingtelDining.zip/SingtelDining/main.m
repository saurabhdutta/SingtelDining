//
//  main.m
//  SingtelDining
//
//  Created by Alex Yao on 6/11/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

int main(int argc, char *argv[]) {
  NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
  int retVal = UIApplicationMain(argc, argv, nil, @"AppDelegate");
  [pool release];
  return retVal;
}
