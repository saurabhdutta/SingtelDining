//
//  MobileIdentifier.h
//  GP_Automobile
//
//  Created by System Administrator on 09/06/10.
//  Copyright 2010 Cellcity Pte Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MobileIdentifier : NSObject {

}

+ (NSString*) getMobileName;
@end
