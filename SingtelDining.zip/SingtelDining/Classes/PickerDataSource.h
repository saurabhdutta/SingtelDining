//
//  PickerDataSource.h
//  SingtelDining
//
//  Created by System Administrator on 22/06/10.
//  Copyright 2010 Cellcity Pte Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PickerDataSource : TTSectionedDataSource {

}

@end
