//
//  SDListView.h
//  SingtelDining
//
//  Created by Alex Yao on 6/15/10.
//  Copyright 2010 CellCity. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SDBoxView.h"


@interface SDListView : SDBoxView {
}

@end
