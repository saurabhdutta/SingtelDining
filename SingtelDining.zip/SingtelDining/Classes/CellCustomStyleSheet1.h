//
//  CellCustomStyleSheet1.h
//  SingtelDining
//
//  Created by System Administrator on 21/06/10.
//  Copyright 2010 Cellcity Pte Ltd. All rights reserved.
//




@interface CellCustomStyleSheet1 : TTDefaultStyleSheet

@property(nonatomic,readonly) UIColor* myHeadingColor;
@property(nonatomic,readonly) UIColor* mySubtextColor;
@property(nonatomic,readonly) UIFont* myHeadingFont;
@property(nonatomic,readonly) UIFont* mySubtextFont;


@end
