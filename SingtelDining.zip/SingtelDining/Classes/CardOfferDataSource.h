//
//  CardOfferDataSource.h
//  SingtelDining
//
//  Created by Alex Yao Cheng on 6/30/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CardOfferDataSource : TTListDataSource {

}

@end
