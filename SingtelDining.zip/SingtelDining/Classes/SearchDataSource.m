//
//  SearchDataSource.m
//  SingtelDining
//
//  Created by Alex Yao on 6/21/10.
//  Copyright 2010 CellCity. All rights reserved.
//

#import "SearchDataSource.h"


@implementation SearchDataSource

@end
